import socket

s = socket.socket()
s.bind(('0.0.0.0', 2121))
s.listen(1)
print("Listening on port 2121...")

conn, addr = s.accept()
with open('received.txt', 'wb') as f:
    while True:
        data = conn.recv(1024)
        if not data:
            break
        f.write(data)
print("File received.")
conn.close()

