import socket
import os

server_ip = input("Nhap dia chi IP may nguoi nhan: ")
file_name = input("Nhap ten file can gui: ")

if not os.path.exists(file_name):
    print(f"File '{file_name}' khong ton tai.")
    exit(1)

s = socket.socket()
try:
    s.connect((server_ip, 2121))
    print(f"Dang gui file '{file_name}' den {server_ip}...")

    with open(file_name, 'rb') as f:
        data = f.read()
        s.sendall(data)

    print("Completed!")
except Exception as e:
    print(f"error")
finally:
    s.close()

