
def text_to_binary(input_file):
    with open(input_file, 'r', encoding='utf-8') as f:
        text = f.read()
    return ''.join(format(ord(char), '08b') for char in text)

def hide_message(binary_string, cover_text, spacing_factor=1):
    words = cover_text.split()
    if len(words) <= len(binary_string):
        raise ValueError("Fail! Don't have enough area.")

    encoded_text = []
    space_0 = "\u200A"         # Hair Space
    space_1 = "\u200A\u200A"   # Two Hair Spaces

    for i, word in enumerate(words[:-1]):
        encoded_text.append(word)
        if i < len(binary_string):
            if binary_string[i] == '0':
                encoded_text.append(space_0)
            else:
                encoded_text.append(space_1)

    encoded_text.append(words[-1])
    return ''.join(encoded_text)

def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip()

def write_file(filename, data):
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(data)

if __name__ == "__main__":
    secret_file = "giautin.txt"
    cover_file = "cover_text.txt"
    output_file = "fake_stego_text.txt"

    binary_message = text_to_binary(secret_file)
    cover_text = read_file(cover_file)
    stego_text = hide_message(binary_message, cover_text)
    write_file(output_file, stego_text)

    print(f"Completed! Stego text saved in {output_file}")
