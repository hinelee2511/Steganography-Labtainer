def text_to_binary(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as f:
        text = f.read()
    
    binary_text = ' '.join(format(ord(char), '08b') for char in text)

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(binary_text)

    print(f"Completed! Binary data saved in {output_file}")

if __name__ == "__main__":
    input_file = "giautin.txt"
    output_file = "binary_output.txt"
    text_to_binary(input_file, output_file)

