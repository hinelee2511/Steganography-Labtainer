import logging
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
logger = logging.getLogger('pyftpdlib')
logger.handlers = []  
logger.addHandler(logging.NullHandler())  
logger.propagate = False  
authorizer = DummyAuthorizer()
authorizer.add_user("user", "123456", "/home/ubuntu", perm="elradfmw")  
handler = FTPHandler
handler.authorizer = authorizer
server = FTPServer(("0.0.0.0", 21), handler)
print("FTP server running on 172.20.0.20:21...")
try:
    server.serve_forever()
except KeyboardInterrupt:
    server.close_all()
    print("FTP Server stopped.")

