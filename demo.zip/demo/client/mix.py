import random

def embed_secret(cover_text_file, secret_binary_file, output_file):
    with open(cover_text_file, 'r', encoding='utf-8') as f:
        cover_words = f.read().split()

    with open(secret_binary_file, 'r', encoding='utf-8') as f:
        secret_bits = f.read().replace(" ", "")  # Loại bỏ khoảng trắng

    if len(secret_bits) > len(cover_words) - 1:
        raise ValueError("Văn bản chứa không đủ độ dài để giấu tin.")

    # Tạo danh sách vị trí hoán đổi dựa trên bit 1 của secret_bits
    modified_words = cover_words.copy()
    for i, bit in enumerate(secret_bits):
        if bit == '1' and i < len(modified_words) - 1:
            modified_words[i], modified_words[i + 1] = modified_words[i + 1], modified_words[i]

    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(" ".join(modified_words))

    print(f"Hide information successfully! The document hidden the news in the {output_file}")

if __name__ == "__main__":
    cover_text_file = "cover_text.txt"
    secret_binary_file = "binary_output.txt"
    output_file = "stego_text.txt"
    
    embed_secret(cover_text_file, secret_binary_file, output_file)

