def extract_secret(cover_text_file, stego_text_file):
    with open(cover_text_file, 'r', encoding='utf-8') as f:
        cover_words = f.read().split()

    with open(stego_text_file, 'r', encoding='utf-8') as f:
        stego_words = f.read().split()

    if len(cover_words) != len(stego_words):
        raise ValueError("Lỗi: Số từ trong file cover và stego không khớp!")

    secret_bits = []
    for i in range(len(cover_words) - 1):
        if cover_words[i] == stego_words[i + 1] and cover_words[i + 1] == stego_words[i]:
            secret_bits.append('1')
        else:
            secret_bits.append('0')
    secret_message = ""
    for i in range(0, len(secret_bits), 8):
        byte = ''.join(secret_bits[i:i+8])
        if len(byte) == 8:
            secret_message += chr(int(byte, 2))
    print(f"Successful decoding! secret message: {secret_message}")

if __name__ == "__main__":
    cover_text_file = "cover_text.txt"
    stego_text_file = "stego_text.txt"
    
    extract_secret(cover_text_file, stego_text_file)

