def extract_message(stego_text):
    words = stego_text.split()
    binary_string = ""
    
    for i in range(len(words) - 1):
        gap = stego_text[stego_text.find(words[i]) + len(words[i]):stego_text.find(words[i + 1])]
        if gap == "\u200A":
            binary_string += "0"
        elif gap == "\u200A\u200A":
            binary_string += "1"
    
    return binary_string

def binary_to_text(binary_string):
    chars = [binary_string[i:i+8] for i in range(0, len(binary_string), 8)]
    text = ''.join([chr(int(char, 2)) for char in chars if len(char) == 8])
    return text
def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        return file.read().strip()

def write_file(filename, data):
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(data)

stego_text = read_file("stego_text.txt")

hidden_binary_message = extract_message(stego_text)
hidden_text = binary_to_text(hidden_binary_message)
write_file("secret_message.txt", hidden_text)
print("Decode completed! file saved in secret_message.txt")

