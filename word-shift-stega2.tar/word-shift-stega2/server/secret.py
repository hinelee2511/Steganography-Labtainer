if (input("enter your password: ")=="A"):
	print("Mission Completed!")
else: 
	print("Bypass Fail!")
	print("You die!")
